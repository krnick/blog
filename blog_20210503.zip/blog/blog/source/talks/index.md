---
title: Talks
date: 2020-09-23 14:16:10
comments: false
---

## Talks

### Black Hat Asia

Black Hat Asia Arsenal 2021

### DEFCON 28

[DEFCON Blue Team Villages 2020 ](https://cfc.blueteamvillage.org/call-for-content-2020/talk/FWDP3K/), [Video](https://www.youtube.com/watch?v=XK-yqHPnsvc&ab_channel=DEFCONConference)

### ROOTCON

[ROOTCON 2020](https://www.rootcon.org/html/recoverymode/talks#quark_engine)

### Hack in the box

[HITB Lockdwon 2020](https://conference.hitb.org/hitb-lockdown002/sessions/quark-engine-an-obfuscation-neglect-android-malware-scoring-system/), [Video](https://conference.hitb.org/hitb-lockdown002/sessions/quark-engine-an-obfuscation-neglect-android-malware-scoring-system/)

[HITB2020AMS Armory](https://conference.hitb.org/hitbsecconf2020ams/hitb-armory/)

### PyCon

- 2020

    [PyCon India 2020](https://in.pycon.org/cfp/2020/proposals/so-you-want-to-build-an-anti-virus-engine~bDM6d/)
    [Europython 2020](https://ep2020.europython.eu/talks/BDppVua-so-you-want-to-build-an-anti-virus-engine/) 
    [PyCon Taiwan 2020](https://tw.pycon.org/2020/zh-hant/conference/talk/1124332019854082369/) 

- 2019

    [PyCon Taiwan 2019](https://www.youtube.com/watch?v=D_WHNa4VO0I) 
    [PyCon Korea 2019](https://www.youtube.com/watch?v=-S4JVQt6GX4)
    [PyCon Malaysia 2019](https://www.youtube.com/watch?v=hDtBRnfe85A)

